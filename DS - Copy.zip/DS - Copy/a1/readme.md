1. `javac *.java`
2. `rmiregistry`
3. `java Server.java`
4. `java Client.java` 
